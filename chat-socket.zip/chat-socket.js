const socket = io("ws://118.67.135.60:3000/")
// const socket = io("ws://localhost:3000/")
var nickname = "운영자";
const room = "d67dc57d-14a3-488b-8f5f-dfeee417ed3c"

const message = document.getElementById('message');
const messages = document.getElementById('messages');
const messagesub = document.getElementById('messagesub');

function Test(arg , chat , roomname){
//  console.log(arg)
 socket.emit('message', arg + ":" + chat +"방이름" + roomname)
//  socket.emit('room', room)             
 nickname = arg
}
             
socket.emit('room', room)             
             
const handleSubmitNewMessage = () => {
  socket.emit('message', nickname + ":" + message.value +"방이름" + room )
}

socket.on('message', (data) => {
  handleNewMessage(data);
})

const handleNewMessage = (message) => {
  // messages.appendChild(buildNewMessage(message));
  // if(message.split(":")[0] === nickname ){
    messages.appendChild(buildNewMessage(message));
  // }
  // else{
  //   messagesub.appendChild(buildNewMessage(message));
  // }
}


const buildNewMessage = (message) => {
  if(message.split(":")[0] === nickname){
  const li = document.createElement("li");
  li.classList.add('test');
  li.appendChild(document.createTextNode(message.split("방이름")[0]))
  return li;
  }
  else{
    const li = document.createElement("li");
    let text = document.createTextNode(message.split("방이름")[0]);
    li.classList.add('dfgjhkd');
    li.appendChild(text);
    document.body.appendChild(li)
    return li;
 
  }
}